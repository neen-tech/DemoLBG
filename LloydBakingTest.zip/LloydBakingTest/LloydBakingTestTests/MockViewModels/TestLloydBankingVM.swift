//
//  TestLloydBankingVM.swift
//  LloydBakingTest
//
//  Created by Nitin on 06/03/25.
//

import XCTest
import Combine
@testable import LloydBakingTest


final class TestLloydBankingVM: ViewModelsProtocols {
   
    @Published var error: String?
    @Published var cats: [Cat] = []
    @Published var isCompleted: Bool
    
    var catDataTestCase: CatDataUseCaseProtocol!
    var cancellables: Set<AnyCancellable>!
    //Initialise
    init(catDataTestCase: CatDataUseCaseProtocol) {
        self.catDataTestCase = catDataTestCase
        isCompleted = false
        cancellables = []
    }
    //MARK: - fetch cats
    func fetchCats() {
        isCompleted = true
        catDataTestCase.fetchCats()
            .sink { completion in
                switch completion{
                case .failure(let error):
                    self.isCompleted = false
                    self.error = error.localizedDescription
                case .finished:
                    self.isCompleted = true
                }
            } receiveValue: { cats in
                self.cats = cats
            }
            .store(in: &cancellables)
        }
}
    

