//
//  LloydBakingTestTests.swift
//  LloydBakingTestTests
//
//  Created by Nitin on 26/02/25.
//

import XCTest
@testable import LloydBakingTest

final class LloydBakingTestTests: XCTestCase {
    var lloyBankingViewmodelObj: ViewModelLloydBanking!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        lloyBankingViewmodelObj = ViewModelLloydBanking()
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        lloyBankingViewmodelObj = nil
        try super.tearDownWithError()
    }
    
    func test_fetch_cats_Data() {
        let expectation = self.expectation(description: "Fetch cat data")
        lloyBankingViewmodelObj.fetchCatData { cats, error in
            if let cats = cats {
                XCTAssertNotNil(cats, "cat can't be nil")
            } else {
                XCTFail("cat is nil")
            }
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 10.0)
    }

}
