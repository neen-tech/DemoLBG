//
//  NetworkManagerTestCases.swift
//  LloydBakingTestTests
//
//  Created by Nitin on 05/03/25.
//

import XCTest
import Combine
@testable import LloydBakingTest

final class NetworkManagerTestCases: XCTestCase {

    var testNetworkManager: NetworkManagerProtocol!
    var cancellables: Set<AnyCancellable>!
    override func setUpWithError() throws {
        testNetworkManager = TestableNetworkManager()
        cancellables = []
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        testNetworkManager = nil
        cancellables = nil
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    
    func test_request_with_success_cat_response() {
        
        let expectation = self.expectation(description: "Fetch cats successfully")
        guard let catsAPIURL = URLRequests.getUrlComponent(from: .catsAPI).url else {
            XCTFail(URLError(.badURL).localizedDescription)
            return
        }
        let localJsonData = loadLocalTestData(from: "TestData", for: ServiceLayerTestCases.self)
        (testNetworkManager as? TestableNetworkManager)?.testData = localJsonData
        testNetworkManager.requestData(for: catsAPIURL)
            .sink { completion in
                switch completion {
                case .failure(let error):
                    XCTFail("Expected success, got error: \(error)")
                case .finished:
                    break
                }
            } receiveValue: { (catResponse:[Cat]) in
                XCTAssertEqual(catResponse.count, 1, "Expected 1 cat in response")
                XCTAssertEqual(catResponse.first?.id, "5l1", "cat's id should be 5l1.")
                expectation.fulfill()
            }
            .store(in: &cancellables)
        wait(for: [expectation], timeout: 5.0)
    }

}
