//
//  ViewModelLloydBankingTestCases.swift
//  LloydBakingTest
//
//  Created by Nitin on 06/03/25.
//

import XCTest
import Combine
@testable import LloydBakingTest

class ViewModelLloydBankingTestCases: XCTestCase {
    
    // allocate the abject of above properties
    var viewModel: TestLloydBankingVM!
    var testCastDataCase: TestCatDataUseCase!
    private var cancellables: Set<AnyCancellable>!
   
    override func setUp() {
        super.setUp()
        cancellables = []
        testCastDataCase = TestCatDataUseCase()
        viewModel = TestLloydBankingVM(catDataTestCase: testCastDataCase)
    }
    
    override func tearDown() {
        super.tearDown()
        testCastDataCase = nil
        viewModel = nil
        cancellables = nil
    }
    
    
    func test_view_model_success_test_case() {
        let expectation = self.expectation(description: "Fetch cat data successfully")
        //Load Test data from TestData.json
        let localJsonData = loadLocalTestData(from: "TestData", for: ServiceLayerTestCases.self)
        let decoder = JSONDecoder()
        // Decode JSON into `UserResponse`
        guard let catResponse = try? decoder.decode([Cat].self, from: localJsonData) else {
            XCTFail("Failed to decode mock cat data.")
            return
        }
        testCastDataCase.testCats = catResponse
        viewModel.fetchCats()
        
        viewModel.$cats
            .sink { cats in
                XCTAssertEqual(cats.count, catResponse.count)
                XCTAssertEqual(cats.first?.id, catResponse.first?.id)
                expectation.fulfill()
        }
        .store(in: &cancellables)
        wait(for: [expectation], timeout: 3.0)
    }
}

//Failure Case
extension ViewModelLloydBankingTestCases {
    func testFetchUsersFailure() {
        let expectation = self.expectation(description: "Fetch users failed")
        testCastDataCase.testError = URLError(.badURL)
        viewModel.fetchCats()
        viewModel.$error
            .sink { error in
                XCTAssertNotNil(error)
                expectation.fulfill()
            }
            .store(in: &cancellables)
        wait(for: [expectation], timeout: 5.0)
    }
}
