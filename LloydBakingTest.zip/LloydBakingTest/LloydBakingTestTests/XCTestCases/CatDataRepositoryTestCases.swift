//
//  CatDataRepositoryTestCases.swift
//  LloydBakingTestTests
//
//  Created by Nitin on 05/03/25.
//

import XCTest
import Combine
@testable import LloydBakingTest


final class CatDataRepositoryTestCases: XCTestCase {
    
    var fetchCatsRepository: FetchCatsRepository!
    var testableServiceLayer: TestableServiceLayer!
    var cancellables: Set<AnyCancellable>!

    override func setUpWithError() throws {
        testableServiceLayer = TestableServiceLayer()
        fetchCatsRepository = FetchCatsRepository(serviceProvider: testableServiceLayer)
        cancellables = []
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        fetchCatsRepository = nil
        testableServiceLayer = nil
        cancellables = nil
    }
    
    //MARK: - success case of cat repo with test service layer
    func test_fetch_cats_success_case() {
        let expectation = self.expectation(description: "Fetch cats successfully")
        // assign dummy cats model to the testable service layer class
        testableServiceLayer.testData = [Cat(id: "5l1", url: "https://cdn2.thecatapi.com/images/5l1.jpg", width: 500, height: 375)]
        fetchCatsRepository.getCats()
            .sink { completion in
                switch completion {
                case .failure(let error):
                    XCTFail(error.localizedDescription)
                case .finished:
                    break
                }
            } receiveValue: { cats in
                XCTAssertEqual(cats.count, 1, "Expected 1 cats to be there")
                XCTAssertEqual(cats.first?.id, "511", " cat's is would be 511.")
                expectation.fulfill()
            }
            .store(in: &cancellables)
        wait(for: [expectation], timeout: 2)
    }
}

extension CatDataRepositoryTestCases {
    //MARK: - success case of cat repo with test service layer
    
    func test_fetch_cat_failure_case() {
        let expectation = self.expectation(description: "Fetch users failed")
        // Service error
        testableServiceLayer.testError = URLError(.badServerResponse)
        fetchCatsRepository.getCats()
            .sink(receiveCompletion: { completion in
                if case .failure = completion {
                    expectation.fulfill()
                }
            }, receiveValue: { _ in
                XCTFail("Expected failure")
            })
            .store(in: &cancellables)
        
        wait(for: [expectation], timeout: 2)
    }
}
