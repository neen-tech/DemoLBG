//
//  TestCatDataRepository.swift
//  LloydBakingTest
//
//  Created by Nitin on 05/03/25.
//

import Foundation
import Combine
@testable import LloydBakingTest

// testable Cat Data Repo
class TestCatDataRepository: CatDataRepository {
   
    var allCatValue: [Cat] = []
    var testError: Error?

    func getCats() -> AnyPublisher<[Cat], any Error> {
        if let error = testError {
            return Fail(error: error).eraseToAnyPublisher()
        }
        return Just(allCatValue)
            .setFailureType(to: Error.self)
            .eraseToAnyPublisher()
    }
    
}

