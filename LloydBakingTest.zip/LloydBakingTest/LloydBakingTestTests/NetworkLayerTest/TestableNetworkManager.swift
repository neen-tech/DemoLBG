//
//  TestableNetworkManager.swift
//  LloydBakingTest
//
//  Created by Nitin on 05/03/25.
//


import Foundation
import Combine
@testable import LloydBakingTest

final class TestableNetworkManager:NetworkManagerProtocol {
    var testData: Data?
    var testError: Error?
    func requestData<T:Decodable>(for url: URL) -> AnyPublisher<T,Error> {
        if let testError = testError {
            return Fail(error: testError).eraseToAnyPublisher()
        }
        guard let data = testData else {
            return Fail(error: URLError(.badServerResponse)).eraseToAnyPublisher()
        }
        do {
            let decodedData = try JSONDecoder().decode(T.self, from: data)
            return Just(decodedData)
                .setFailureType(to: Error.self)
                .eraseToAnyPublisher()
        } catch {
            return Fail(error: error).eraseToAnyPublisher()
        }
    }
    
}
