//
//  TestCatDataUseCase.swift
//  LloydBakingTest
//
//  Created by Nitin on 06/03/25.
//


import Foundation
import Combine
@testable import LloydBakingTest

/// A mock implementation of `GetUserDataUseCaseProtocol` to simulate API responses for testing.
class TestCatDataUseCase: CatDataUseCaseProtocol {
    
    var testCats: [Cat] = []
    var testError: Error?

    func fetchCats() -> AnyPublisher<[Cat], Error> {
        if let error = testError {
            return Fail(error: error).eraseToAnyPublisher()
        }
        return Just(testCats)
            .setFailureType(to: Error.self)
            .eraseToAnyPublisher()
    }
    
}

