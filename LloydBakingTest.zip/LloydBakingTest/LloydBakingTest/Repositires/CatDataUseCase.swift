//
//  CatDataUseCase.swift
//  LloydBakingTest
//
//  Created by Nitin on 06/03/25.
//
import Combine


protocol CatDataUseCaseProtocol {
   func fetchCats() -> AnyPublisher<[Cat], Error>
}
//Cat use case class 
final class CatDataUseCase: CatDataUseCaseProtocol {
    let catRepository: CatDataRepository
    
    init(catRepository: CatDataRepository) {
        self.catRepository = catRepository
    }
    
    func fetchCats() -> AnyPublisher<[Cat], Error> {
        return catRepository.getCats()
    }
}
