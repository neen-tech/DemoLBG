//
//  CatDataRepository.swift
//  LloydBakingTest
//
//  Created by Nitin on 05/03/25.
//

import Foundation
import Combine

protocol CatDataRepository {
    func getCats() -> AnyPublisher<[Cat], Error>
}




