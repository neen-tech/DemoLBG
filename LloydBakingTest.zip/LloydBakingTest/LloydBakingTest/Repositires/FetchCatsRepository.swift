//
//  FetchCatsRepository.swift
//  LloydBakingTest
//
//  Created by Nitin on 05/03/25.
//

import Combine

final class FetchCatsRepository {
    let serviceProvider: ServiceLayersProtocol
    
    init(serviceProvider: ServiceLayersProtocol) {
        self.serviceProvider = serviceProvider
    }
}

extension FetchCatsRepository:CatDataRepository {
    func getCats() -> AnyPublisher<[Cat], any Error> {
        return self.serviceProvider.getServiceData()
            .eraseToAnyPublisher()
    }
}
