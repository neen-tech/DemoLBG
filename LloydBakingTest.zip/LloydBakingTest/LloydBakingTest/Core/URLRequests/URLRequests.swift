//
//  URLRequests.swift
//  LloydBakingTest
//
//  Created by Nitin on 26/02/25.
//

import Foundation


// URL Request class build your server request using Router enum which have some properties
class URLRequests {
    static func getUrlComponent(from router: Router) -> URLComponents {
        var components = URLComponents()
        components.scheme = router.scheme
        components.host = router.host
        components.path = router.path
        components.queryItems = router.query
        return components
    }
}

