//
//  URLRequests.swift
//  LloydBakingTest
//
//  Created by Nitin on 26/02/25.
//

import Foundation


// URL Request class build your server request using Router enum which have some properties
class URLRequests {

    static func request(from router: Router) throws -> URLRequest {
        var components = URLComponents()
        components.scheme = router.scheme
        components.host = router.host
        components.path = router.path
        components.queryItems = router.query
        guard let url = components.url else {
            throw NetworkError.customError("Invalid URL")
        }
         
//        let urlString = "https://api.thecatapi.com/v1/images/search?limit=10"
//        guard let url = URL(string: urlString) else {
//            throw NetworkError.customError("Invalid URL")
//        }
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = router.method
        urlRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        urlRequest.timeoutInterval = 60.0
        
        switch router.method {
        case "GET":
            urlRequest.httpBody = try getApiRequest()
        default:
            urlRequest.httpBody = try getApiRequest()
        }
        
        printRequest(urlRequest)
        return urlRequest
    }
    
    private static func printRequest(_ request: URLRequest) {
        print("Request: \(request)")
    }
}

extension URLRequests {
    
    static func getApiRequest() throws -> Data? {
        return nil
    }
}
