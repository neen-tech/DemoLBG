//
//  LloydBankingServiceLayers.swift
//  LloydBakingTest
//
//  Created by Nitin on 27/02/25.
//

class LloydBankingServiceLayers {
    static func request<T: Codable>(router: Router) async throws -> T {
        let request = try URLRequests.request(from: router)
        let data = try await NetworkManager.requestData(for: request)
        let responseObject: T = try LBJsonDecoder.decode(data: data)
        return responseObject
    }
}
