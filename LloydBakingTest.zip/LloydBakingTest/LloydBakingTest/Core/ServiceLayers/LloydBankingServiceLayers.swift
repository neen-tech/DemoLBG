//
//  LloydBankingServiceLayers.swift
//  LloydBakingTest
//
//  Created by Nitin on 27/02/25.
//


import Foundation
import Combine

protocol ServiceLayersProtocol {
    func getServiceData() -> AnyPublisher<[Cat],Error>
}

class ServiceLayers {
    let networkManager:NetworkManagerProtocol
    init(networkManager: NetworkManagerProtocol) {
        self.networkManager = networkManager
    }
}

extension ServiceLayers: ServiceLayersProtocol {
    func getServiceData() -> AnyPublisher<[Cat],Error> {
        guard let url =  URLRequests.getUrlComponent(from: .catsAPI).url else {
            return Fail(error: URLError(.badURL)).eraseToAnyPublisher()
        }
        return self.networkManager.requestData(for: url)
    }
}



