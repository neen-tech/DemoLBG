//
//  Router.swift
//  LloydBakingTest
//
//  Created by Nitin on 26/02/25.
//

import Foundation

enum Router {
    case catsAPI
    
    var host: String {
        switch self {
        case .catsAPI:
            return BaseUrl.CATURL
        }
    }
    
    var scheme: String {
        switch self {
        case .catsAPI:
            return "https"
        }
    }

    var path: String {
        switch self {
        case .catsAPI:
            return Path.cats
        }
    }

    var method: String {
        switch self {
        case .catsAPI:
            return HttpMethod.get.rawValue
        }
    }
    
    var query: [URLQueryItem] {
        switch self {
        case .catsAPI:
            return  [URLQueryItem(name: "limit", value: "20")]
        }
    }
    
    var parameters: [String: Any] {
        switch self {
        case .catsAPI:
            return [:]
        }
    }
}

