//
//  Router.swift
//  LloydBakingTest
//
//  Created by Nitin on 26/02/25.
//

import Foundation

enum Router {
    case factsAPI
    case catsAPI
    
    var host: String {
        switch self {
        case .factsAPI:
            return BaseUrl.URL
        case .catsAPI:
            return BaseUrl.CATURL
        }
    }
    
    var scheme: String {
        switch self {
        case .factsAPI, .catsAPI:
            return "https"
        }
    }

    var path: String {
        switch self {
        case .factsAPI:
            return Path.facts
        case .catsAPI:
            return Path.cats
        }
    }

    var method: String {
        switch self {
        case.factsAPI, .catsAPI:
            return HttpMethod.get.rawValue
        }
    }
    
    var query: [URLQueryItem] {
        switch self {
        case .factsAPI:
            return []
        case .catsAPI:
            return  [URLQueryItem(name: "limit", value: "10")]
        }
    }
    
    var parameters: [String: Any] {
        switch self {
        case .factsAPI, .catsAPI:
            return [:]
        }
    }
}

