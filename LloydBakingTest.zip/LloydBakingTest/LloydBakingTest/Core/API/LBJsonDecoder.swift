//
//  LBJsonDecoder.swift
//  LloydBakingTest
//
//  Created by Nitin on 26/02/25.
//  Copyright @ 2023 Lloyd Banking group. All rights reserved.
//

import Foundation

// Lloyd Banking Test Json Decorder
class LBJsonDecoder {
    static func decode<T: Codable>(data: Data) throws -> T {
        let decoder = JSONDecoder()
        let decodedObject = try decoder.decode(T.self, from: data)
        print(decodedObject)
        return decodedObject
    }
}
