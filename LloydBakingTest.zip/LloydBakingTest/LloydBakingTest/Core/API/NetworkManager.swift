//
//  NetworkManager.swift
//  LloydBakingTest

//  Created by Nitin on 26/02/25.
//  Copyright @ 2023 Lloyd Banking group. All rights reserved.
//

import Foundation
import Combine

protocol NetworkManagerProtocol {
    func requestData<T: Decodable>(for url: URL) -> AnyPublisher<T, Error>
}
// Network Manager class with Sin
final class NetworkManager {
    static let shared = NetworkManager()
    let session:URLSession
    init(session: URLSession = .shared) {
        self.session = session
    }
}

extension NetworkManager: NetworkManagerProtocol {
    
    func requestData<T: Decodable>(for url: URL) -> AnyPublisher<T, Error> {
        return session.dataTaskPublisher(for: url)
            .tryMap { result -> Data in
                guard let response = result.response as? HTTPURLResponse, (200...299).contains(response.statusCode) else {
                    throw URLError(.badServerResponse)
                }
                return result.data
            }
           // .tryMap(\.data)
            .decode(type: T.self, decoder: JSONDecoder())
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
}
