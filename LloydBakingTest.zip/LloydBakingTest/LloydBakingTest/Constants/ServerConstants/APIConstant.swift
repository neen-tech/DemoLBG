//
//  Untitled.swift
//  LloydBakingTest
//
//  Created by Nitin on 26/02/25.
//

struct BaseUrl {
    static let CATURL = "api.thecatapi.com"
}

struct Path {
    static let cats = "/v1/images/search"
}

enum HttpMethod: String {
    case get = "GET"
    case post = "POST"
}


