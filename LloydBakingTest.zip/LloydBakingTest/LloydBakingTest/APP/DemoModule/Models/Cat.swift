//
//  Cat.swift
//  LloydBakingTest
//
//  Created by Nitin on 27/02/25.
//

import Foundation

// MARK: - Cat
struct Cat: Codable {
    let id: String
    let url: String
    let width, height: Int
}
