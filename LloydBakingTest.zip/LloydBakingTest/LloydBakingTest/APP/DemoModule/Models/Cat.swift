//
//  Cat.swift
//  LloydBakingTest
//
//  Created by Nitin on 27/02/25.
//

import Foundation

// MARK: - Cat
struct Cat: Decodable {
    let id: String
    let url: String
    let width, height: Int
    
    init(id: String, url: String, width: Int, height: Int) {
        self.id = id
        self.url = url
        self.width = width
        self.height = height
    }
}
