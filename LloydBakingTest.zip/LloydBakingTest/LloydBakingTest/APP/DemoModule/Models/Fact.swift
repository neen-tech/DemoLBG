//
//  Untitled.swift
//  LloydBakingTest
//
//  Created by Nitin on 27/02/25.
//


import Foundation
// MARK: - Fact
struct Fact: Codable {
    let id: String?
    let v: Int?
    let text, updatedAt: String?
    let deleted: Bool?
    let source: String?
    let sentCount: Int?

    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case v = "__v"
        case text, updatedAt, deleted, source, sentCount
    }
}


