//
//  ViewModelLloydBanking.swift
//  LloydBakingTest
//
//  Created by Nitin on 26/02/25.
//

import Foundation
import UIKit

protocol LloydBankingFetchDataProtocol {
    func fetchCatData(completion: @escaping ([Cat]?, Error?) -> Void)
}

protocol LloydBankingUpdateDataProtocol: AnyObject {
    func updateViewController()
}


final class ViewModelLloydBanking:LloydBankingFetchDataProtocol {
    var cats: [Cat]?
    weak var delegate : LloydBankingUpdateDataProtocol?
    
    init(){
        
    }
    
    func fetchData(viewController: UIViewController) {
        AppLoader.shared.startLoading(view: viewController.view)
        self.fetchCatData(completion: { [weak self] cats, error in
            guard let strongSelf = self else { return }
            if let cats = cats {
                strongSelf.cats = cats
                DispatchQueue.main.async {
                    AppLoader.shared.stopLoading()
                    strongSelf.delegate?.updateViewController()
                }
            }
        })
    }
    
    //MARK: - fetch
    func fetchCatData(completion: @escaping ([Cat]?, Error?) -> Void) {
        Task {
            do {
                if let cats:[Cat] = try await LloydBankingServiceLayers.request(router: .catsAPI) {
                    completion(cats, nil)
                }
            } catch {
                completion(nil, error)
                ErrorHandler.handle(error: error)
            }
        }
    }
    
    func getInfoForCat(for indexPath: IndexPath) -> (catDetails: Cat?, isFirstIndex: Bool, isLastIndex: Bool) {
        let cats = self.cats
        let catsObj = cats?[indexPath.row]
        let isLastIndex = (indexPath.row == ((cats?.count ?? 0 ) - 1)) ? true : false
        let isFirstIndex = (indexPath.row == 0) ? true : false
        return (catDetails: catsObj, isFirstIndex: isFirstIndex, isLastIndex: isLastIndex)
    }
}
