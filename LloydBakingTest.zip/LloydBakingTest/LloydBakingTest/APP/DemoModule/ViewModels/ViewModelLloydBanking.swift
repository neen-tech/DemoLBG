//
//  ViewModelLloydBanking.swift
//  LloydBakingTest
//
//  Created by Nitin on 26/02/25.
//

import Foundation
import UIKit
import Combine


final class ViewModelLloydBanking {
    var error: String?
    @Published var isCompleted: Bool
    @Published var cats: [Cat] = []
    private var cancellables = Set<AnyCancellable>()
    let sevicesLayer :FetchCatsRepository
    init(sevicesLayer :FetchCatsRepository){
        self.sevicesLayer = sevicesLayer
        self.isCompleted = false
    }
    //MARK: fetch cats data from server
    func fetchCats() {
        self.sevicesLayer.getCats()
            .sink { [weak self] completion in
                self?.isCompleted = false  // Stop loading after request completes
                switch completion {
                case .failure(let error):
                    self?.error = error.localizedDescription  // Store error message
                case .finished:
                    self?.isCompleted = true
                    break
                }
            } receiveValue: { [weak self] cats in
                self?.cats = cats
            }
            .store(in: &cancellables)
    }
}
