//
//  LloydBankingCell.swift
//  LloydBakingTest
//
//  Created by Nitin on 27/02/25.
//

import UIKit

class LloydBankingCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var url: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(info: (catDetails: Cat?, isFirstIndex: Bool, isLastIndex: Bool), rowIndex: Int) {
        guard let catObj = info.catDetails else {return}
        nameLabel.text = catObj.id
        url.text = catObj.url
    }

}
