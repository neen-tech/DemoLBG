//
//  ViewContollerLloydBanking.swift
//  LloydBakingTest
//
//  Created by Nitin on 26/02/25.
//

import UIKit

class ViewContollerLloydBanking: UIViewController {
    
    var lloydBankingViewModel:ViewModelLloydBanking?
    @IBOutlet weak var tableViewLB: UITableView!
    
    //MARK: - Reload Table
    func reloadTable() {
        DispatchQueue.main.async {
            self.tableViewLB.reloadData()
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // Initial UI component setup
        setupUI()
        // Fetching Data from API
        fetchData()
    }
}

