

//
//  ViewContollerLloydBanking.swift
//  LloydBakingTest
//
//  Created by Nitin on 27/02/25.
//

import UIKit
// MARK: - extention for view TableView Delegate
extension ViewContollerLloydBanking: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.lloydBankingViewModel?.cats?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let lloydBankingCell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.lloydBankingCell,
                                                                  for: indexPath) as? LloydBankingCell else {
            return UITableViewCell()
        }
        guard let infoForCat = self.lloydBankingViewModel?.getInfoForCat(for: indexPath) else { return UITableViewCell()}
        lloydBankingCell.configure(info: infoForCat, rowIndex: indexPath.row)
        return lloydBankingCell
    }
}


//MARK: - extention for view controller protocol
extension ViewContollerLloydBanking:ViewContollerProtocol {
    func fetchData() {
        lloydBankingViewModel?.fetchCatData(completion: { [weak self] cats, error in
            guard let strongSelf = self else { return }
            if let cats = cats {
                strongSelf.lloydBankingViewModel?.cats = cats
                strongSelf.loadUI()
            }
        })
    }

    // Load UI
    func loadUI() {
        self.reloadTable()
    }
    // Setup UI conponents
    func setupUI() {
        //set Navigation Title
        self.title = "Cat Details"
        // setup table delegate
        tableViewLB.dataSource = self
        //tableViewLB.delegate = self
        // View Model Object
        lloydBankingViewModel = ViewModelLloydBanking()
        lloydBankingViewModel?.delegate = self
        // Registing the table View Cell
        tableViewLB.register(UINib(nibName: CellIdentifiers.lloydBankingCell, bundle: nil), forCellReuseIdentifier: CellIdentifiers.lloydBankingCell)
    }
}

//MARK: - extention for UpdateViewController protocol
extension ViewContollerLloydBanking: LloydBankingUpdateDataProtocol {
    func updateViewController() {
        self.loadUI()
    }
}


