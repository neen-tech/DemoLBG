

//
//  ViewContollerLloydBanking.swift
//  LloydBakingTest
//
//  Created by Nitin on 27/02/25.
//

import UIKit
// MARK: - extention for view TableView Delegate
extension ViewContollerLloydBanking: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.lloydBankingViewModel?.cats.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let lloydBankingCell = tableView.dequeueReusableCell(withIdentifier: CellIdentifiers.lloydBankingCell,
                                                                  for: indexPath) as? LloydBankingCell else {
            return UITableViewCell()
        }
        if let cat = self.lloydBankingViewModel?.cats[indexPath.row] {
            lloydBankingCell.nameLabel.text = cat.id
            lloydBankingCell.url.text = cat.url
        }
        return lloydBankingCell
    }
}


//MARK: - extention for view controller protocol
extension ViewContollerLloydBanking:ViewContollerProtocol {
    // Load UI
    func loadUI() {
        AppLoader.shared.startLoading(view: self.view)
        self.lloydBankingViewModel?.$isCompleted.sink(receiveValue: { [weak self] bool in
            if bool {
                AppLoader.shared.stopLoading()
                self?.reloadTable()
            }
        }).store(in:&cancellables)
    }
    
    // Setup UI conponents on view
    func setupUI() {
        //set Navigation Title
        self.title = "Cat Details"
        // Registing the table View Cell
        tableViewLB.register(UINib(nibName: CellIdentifiers.lloydBankingCell, bundle: nil), forCellReuseIdentifier: CellIdentifiers.lloydBankingCell)
        // setup table delegate
        tableViewLB.dataSource = self
        // View Model Object
        let serviceLayers = ServiceLayers(networkManager: NetworkManager.shared)
        let catsRepository = FetchCatsRepository(serviceProvider: serviceLayers)
        lloydBankingViewModel = ViewModelLloydBanking(sevicesLayer: catsRepository)
        lloydBankingViewModel?.fetchCats()
        self.loadUI()
    }
}


