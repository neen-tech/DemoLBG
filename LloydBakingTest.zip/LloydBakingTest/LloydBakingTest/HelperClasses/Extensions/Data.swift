//
//  Data.swift
//  LloydBakingTest
//
//  Created by Nitin on 27/02/25.
//

import Foundation

extension Data {
    func toString(encoding: String.Encoding = .utf8) -> String? {
        return String(data: self, encoding: encoding)
    }
    
    var prettyPrintedJSONString: NSString? {
        guard let jsonObject = try? JSONSerialization.jsonObject(with: self, options: []),
              let data = try? JSONSerialization.data(withJSONObject: jsonObject,
                                                     options: [.prettyPrinted]),
              let prettyJSON = NSString(data: data, encoding: String.Encoding.utf8.rawValue) else {
            return nil
        }
        return prettyJSON
    }
    
    mutating public func append(_ string: String) {
        debugPrint(string)
        if let data = string.data(using: .utf8) {
            append(data)
            debugPrint("data==>",data)
        }
    }
}
