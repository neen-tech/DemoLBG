//
//  PopulateProtocol.swift
//  LloydBakingTest
//
//  Created by Nitin on 27/02/25.
//

import Foundation

protocol PopulateProtocol {
    func loadUI()
}

protocol ScreenUISetupProtocol {
     func setupUI()
}

protocol ViewContollerProtocol: PopulateProtocol, ScreenUISetupProtocol {
    
}

