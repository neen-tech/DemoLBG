//
//  ViewModelsProtocols.swift
//  LloydBakingTest
//
//  Created by Nitin on 05/03/25.
//

import Foundation

// View Model protocol
protocol ViewModelsProtocols {
    var error: String? { get }
    func fetchCats()
}
