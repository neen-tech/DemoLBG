//
//  AppConstants.swift
//  LloydBakingTest
//
//  Created by Nitin on 27/02/25.
//

struct StoryBoardID {
    static let vcLloydBanking = "ViewContollerLloydBanking"
}

struct StoryBoardName {
    static let Main = "Main"
}

struct CellIdentifiers {
    static let lloydBankingCell = "LloydBankingCell"
}

