//
//  Untitled.swift
//  LloydBakingTest
//
//  Created by Nitin on 05/03/25.
//

import Foundation
import Combine
@testable import LloydBakingTest

class TestableServiceLayer: ServiceLayersProtocol {
    var testData: [Cat]?
    var testError: Error?
    // ServiceLayerProtocol Method implimation
    
    func getServiceData() -> AnyPublisher<[Cat], any Error> {
        if let error = testError {
            return Fail(error: error).eraseToAnyPublisher()
        }
        if let testData = testData {
            return Just(testData)
                .setFailureType(to: Error.self)
                .eraseToAnyPublisher()
        }
        return Fail(error: URLError(.badServerResponse)).eraseToAnyPublisher()
    }
}
