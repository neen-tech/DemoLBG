//
//  ServiceLayerTestCases.swift
//  LloydBakingTest
//
//  Created by Nitin on 05/03/25.
//


import XCTest
import Combine
@testable import LloydBakingTest

class ServiceLayerTestCases: XCTestCase {
    var serviceLayer: ServiceLayers!
    var testableNetworkManager: TestableNetworkManager!
    var cancellables: Set<AnyCancellable>!
    
    // allocate the abject of above properties
    override func setUp() {
        super.setUp()
        testableNetworkManager = TestableNetworkManager()
        serviceLayer = ServiceLayers(networkManager: testableNetworkManager)
        cancellables = []
    }
    
    override func tearDown() {
        testableNetworkManager = nil
        serviceLayer = nil
        cancellables = nil
        super.tearDown()
    }
    
    func test_fetch_cats_success_case() {
        let expectation = self.expectation(description: "Fetch cat data successfully")
        //Load Test data from TestData.json
        let localJsonData = loadLocalTestData(from: "TestData", for: ServiceLayerTestCases.self)
        testableNetworkManager.testData = localJsonData
        serviceLayer.getServiceData()
            .sink(receiveCompletion: { _ in },
                  receiveValue: { response in
                    XCTAssertEqual(response.count, 1, "Expected 1 cat in response")
                    XCTAssertEqual(response.first?.id, "5l1", "cat's id should be 5l1.")
                    expectation.fulfill()
                  })
            .store(in: &cancellables)
        
        wait(for: [expectation], timeout: 2)
    }
}

//MARK: - failure case of request
extension ServiceLayerTestCases {
    
    func testing_request_failure_case() {
        let expectation = self.expectation(description: "Fetch data failed")
        guard let badURL = URL(string: "https://api.thecatapi.com//v1/images/search?number=20") else {
            XCTFail(URLError(.badURL).localizedDescription)
            return
        }
        (testableNetworkManager)?.testError = URLError(.badServerResponse)
        testableNetworkManager.requestData(for: badURL)
            .sink(receiveCompletion: { completion in
                if case .failure = completion {
                    expectation.fulfill()
                }
            }, receiveValue: { (responseCat:Cat) in
                XCTFail("Expected failure, but got success")
            })
            .store(in: &cancellables)

        wait(for: [expectation], timeout: 5.0)
    }
}
